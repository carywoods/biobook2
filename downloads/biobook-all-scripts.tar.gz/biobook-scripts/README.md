# Bioinformatics with AI — Source Code

All scripts from the book *Bioinformatics with AI: A Modern Introduction to
Computational Biology and Artificial Intelligence* by Dr. Cary Woods.

## Contents

```
python/    78 scripts — 39 "vanilla" + 39 "AI" versions, chapters 1-14
perl/      49 scripts + BeginPerlBioinfo.pm (companion module)
```

## The vanilla / AI pairing

Every Python example comes in two versions:

- **`chNN_vanilla_NN.py`** — standard Python and BioPython only. These run with
  no API key and no network access.
- **`chNN_ai_NN.py`** — the same task, with an LLM added to interpret results.

Read them side by side. The point of the book is the difference between them.

## Running the Python scripts

Python 3.9 or newer.

```bash
cd python
python3 ch01_vanilla_01.py
```

Most scripts use only the standard library. Some need BioPython and the usual
scientific stack:

```bash
pip install biopython pandas matplotlib numpy
```

### Setting up the AI scripts

The AI scripts need the `openai` package (they speak the OpenAI-compatible API):

```bash
pip install openai
```

Then set your key. The scripts default to **OpenRouter**:

```bash
export OPENAI_API_KEY="sk-..."
python3 ch01_ai_01.py
```

Three environment variables are honored:

| Variable | Default | Purpose |
|---|---|---|
| `OPENAI_API_KEY` | *(empty)* | your API key |
| `OPENAI_BASE_URL` | `https://openrouter.ai/api/v1` | API endpoint |
| `OPENAI_MODEL` | `google/gemini-2.5-flash` | model to call |

To use a local model instead (e.g. Ollama):

```bash
export OPENAI_BASE_URL="http://localhost:11434/v1"
export OPENAI_MODEL="llama3"
export OPENAI_API_KEY="ollama"   # any non-empty value
```

**If the `openai` package is not installed**, the AI scripts print
`Note: Install openai package for AI features` and continue — the AI-generated
commentary is replaced with a placeholder message, but the script still runs its
biological analysis. You can study every script without a key.

Note: if the package *is* installed but the key is missing or invalid, the API
call itself will raise an error. Set a key before running the AI versions.

## Running the Perl scripts

The Perl examples accompany the classic *Beginning Perl for Bioinformatics*
material. They rely on the bundled `BeginPerlBioinfo.pm`, so run them from
inside the `perl/` directory:

```bash
cd perl
perl example10-1.pl
```

If you run one from elsewhere, point Perl at the module directory:

```bash
perl -I/path/to/perl example10-1.pl
```

## Verification

At packaging time:

- all 78 Python scripts pass `python3 -m py_compile` (0 syntax errors)
- `pyflakes` reports 0 unused imports and 0 undefined names
- all 49 Perl scripts pass `perl -I. -c`

## License and use

Provided for educational use alongside the book. The Perl companion scripts
derive from *Beginning Perl for Bioinformatics* (James Tisdall) and remain the
property of their original author.
